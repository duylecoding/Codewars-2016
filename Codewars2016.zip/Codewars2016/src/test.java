public class test {

    public static void main(String[] args){
        for(;;)
            System.out.println("hi");
    }
}
